package icesi.edu.co.control;

import icesi.edu.co.modelo.*;

public class Ejecutable {
	
	public static Bodega miBodega;
	public static Empacador empacador;
	public static Descargador descargador;
	
	public static void main (String args[]){
		
		miBodega = new Bodega();
		
		empacador = new Empacador(miBodega);
		descargador = new Descargador(miBodega);
		
		descargador.start();
		
		empacador.start();
		
	}
	
	
	
}
