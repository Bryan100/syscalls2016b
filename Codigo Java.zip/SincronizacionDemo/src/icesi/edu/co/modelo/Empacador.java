package icesi.edu.co.modelo;

public class Empacador extends Thread {

	private Bodega bodega;

	public Empacador(Bodega bodega) {

		this.bodega = bodega;

	}

	public void run() {

		while (true) {

			try {

				if (bodegaConRecursosDisponibles()) {

					bodega.crearPaquete();

				}

				sleep(500);

			} catch (InterruptedException e) {

				e.printStackTrace();
			}
		}
	}

	private boolean bodegaConRecursosDisponibles() {

		return bodega.getCantidadArticuloTipo1() >= 3
				&& bodega.getCantidadArticuloTipo2() >= 4;

	}

}
