package icesi.edu.co.modelo;

public class Bodega {

	public final static int VOLUMEN_MAXIMO = 200;

	private int cantidadArticuloTipo1;

	private int cantidadArticuloTipo2;

	private int volumen_Disponible;

	public Bodega() {

		cantidadArticuloTipo1 = 0;

		cantidadArticuloTipo2 = 0;

		volumen_Disponible = VOLUMEN_MAXIMO;
	}

	public void descargarArticulo(int tipo) {

		if (tipo == 1) {

			cantidadArticuloTipo1 = cantidadArticuloTipo1 + 1;

			volumen_Disponible = volumen_Disponible - 10;
			
			System.out.println(" - - - - - - - - - - - -");
			System.out.println("Se ha descargado un Articulo Tipo1!");
			System.out.println(" ");

		}

		if (tipo == 2) {

			cantidadArticuloTipo2 = cantidadArticuloTipo2 + 1;

			volumen_Disponible = volumen_Disponible - 15;
			
			System.out.println(" - - - - - - - - - - - -");
			System.out.println("Se ha descargado un Articulo Tipo2!");
			System.out.println(" ");
		}
		
		
	
		darEstado();
		

	}

	public void crearPaquete() {

		cantidadArticuloTipo1 = cantidadArticuloTipo1 - 3;

		volumen_Disponible = volumen_Disponible + (3 * 10); // Se liberan 30 de
															// volumen. 10 Por
															// cada Articulo
															// Tipo1 sacado.

		cantidadArticuloTipo2 = cantidadArticuloTipo2 - 4;

		volumen_Disponible = volumen_Disponible + (4 * 15); // Se liberan 60 de
															// volumen. 15 Por
															// cada Articulo
															// Tipo2 sacado.
		
		System.out.println(" - - - - - - - - - - - -");
		System.out.println("Se ha creado un paquete!");
		System.out.println(" ");
		
		darEstado();
		

	}

	public int getCantidadArticuloTipo1() {
		return cantidadArticuloTipo1;
	}

	public int getCantidadArticuloTipo2() {
		return cantidadArticuloTipo2;
	}

	public double getVolumen_Disponible() {
		return volumen_Disponible*100/VOLUMEN_MAXIMO;
	}
	
	public double getVolumen_Ocupado(){
		return (VOLUMEN_MAXIMO - volumen_Disponible)*100/VOLUMEN_MAXIMO;
	}
	
	public int getVolumenDisponible(){
		return volumen_Disponible;
	}
	public void darEstado(){
		
		System.out.println("Estado de la Bodega:");
		System.out.println("Volumen Ocupado: " + getVolumen_Ocupado() + "% - " + "Volumen Disponible: " + getVolumen_Disponible() + "%");
		System.out.println("Cantidad Articulos Tipo 1: "+ getCantidadArticuloTipo1() + " - " + "Cantidad Articulos Tipo 2: " + getCantidadArticuloTipo2());
		System.out.println(" ");
	}

	
}
