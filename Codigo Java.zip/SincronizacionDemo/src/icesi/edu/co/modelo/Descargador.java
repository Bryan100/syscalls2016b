package icesi.edu.co.modelo;

public class Descargador extends Thread {

	private Bodega bodega;

	public Descargador(Bodega bodega) {

		this.bodega = bodega;

	}

	public void run() {

		while (true) {

			try {

				int tipo = (int) (Math.random() * 2 + 1);

				if (sePuedeGuardar(tipo)) {
					
					bodega.descargarArticulo(tipo);			
				}
				
				sleep(500);

			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}
	}

	private boolean sePuedeGuardar(int tipo) {
		
		boolean puede = false; 
		
		if (tipo == 1) {
			puede = bodega.getVolumenDisponible() - 10 >= 0;
		}
		else if (tipo == 2) {
			puede = bodega.getVolumenDisponible() - 15 >= 0;

		}
		
		return puede;
	}

}
